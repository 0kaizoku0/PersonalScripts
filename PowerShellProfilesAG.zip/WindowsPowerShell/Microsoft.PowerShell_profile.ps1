function 01_CopyGeneratedToSrcInclude {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\01_CopyGeneratedToSrcInclude.ps1"
Write-Host "Copy End"
}
Set-Alias -Name RN14copyGenerated -Value 01_CopyGeneratedToSrcInclude

function 02_CompareGenerated {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\02_CompareGenerated.cmd"
Write-Host "Compare End"
}
Set-Alias -Name RN14compareGenerated -Value 02_CompareGenerated

function 03_cleanBuild {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\03_cleanBuild.cmd"
}
Set-Alias -Name RN14cBuild -Value 03_cleanBuild

function 04_RN14CopyBinBL_BenchOptions {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\04_RN14CopyBinBL_BenchOptions.cmd"
Write-Host "The bin folder has been copied" -ForegroundColor Yellow
}
Set-Alias -Name RN14copyBinBL -Value 04_RN14CopyBinBL_BenchOptions

function 05_generatedCode {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\01_CopyGeneratedToSrcInclude.ps1"
& "$userFolder\Scripts\02_CompareGenerated.cmd"
Write-Host "BL\generated folder updated" -ForegroundColor Yellow

}
Set-Alias -Name RN14BLgenerated -Value 05_generatedCode


function 06_Start_Tresos {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\06_Start_Tresos.bat"
& "$userFolder\Scripts\Tresos\CopyCleanGenerator.ps1"
}
Set-Alias -Name RN14tresosws -Value 06_Start_Tresos

function 07_buildLog {
# Get the user folder and store it in a variable
$userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
# Print the user folder
# Write-Host "User Folder: $userFolder"
& "$userFolder\Scripts\07_buildLog.cmd"
}
Set-Alias -Name RN14lBuild -Value 07_buildLog

function 08_buildLogBLUP {
  # Get the user folder and store it in a variable
  $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
  # Print the user folder
  # Write-Host "User Folder: $userFolder"
  & "$userFolder\Scripts\08_buildLogBLUP.cmd"
  }
  Set-Alias -Name RN14lBuildBlup -Value 08_buildLogBLUP

  function 09_OpenDetailedDesign {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\09_OpenDetailedDesign.cmd"
    }
    Set-Alias -Name RN14DetailedDesign -Value 09_OpenDetailedDesign
  
  function 10_CopyModifiedFiles {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\10_CopyModifiedFiles.ps1"
    }
    Set-Alias -Name CopyModifiedFiles -Value 10_CopyModifiedFiles
  
# Import the Chocolatey Profile that contains the necessary code to enable
# tab-completions to function for `choco`.
# Be aware that if you are missing these lines from your profile, tab completion
# for `choco` will not function.
# See https://ch0.co/tab-completion for details.
$ChocolateyProfile = "$env:ChocolateyInstall\helpers\chocolateyProfile.psm1"
if (Test-Path($ChocolateyProfile)) {
  Import-Module "$ChocolateyProfile"
}

# ================ Start 11_gitSync ================ #
  function 11_gitSync {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\11_gitSync.cmd"
    }
    Set-Alias -Name gitSync -Value 11_gitSync
# ================ End 11_gitSync ================== #

# ================ Start 12_gitResetCleanFdx ================ #
  function 12_gitResetCleanFdx {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\12_gitResetCleanFdx.cmd"
    }
    Set-Alias -Name gitResetCleanFdx -Value 12_gitResetCleanFdx
# ================ End 12_gitResetCleanFdx ================== #

# ================ Start 13_codeLastBuild ================ #
  function 13_codeLastBuild {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\13_codeLastBuild.cmd"
    }
    Set-Alias -Name codeLastBuild -Value 13_codeLastBuild
# ================ End 13_codeLastBuild ================== #

# ================ Start 14_CopyBinariesToBench ================ #
  function 14_CopyBinariesToBench {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\14_CopyBinariesToBench.cmd"
    }
    Set-Alias -Name CopyBinariesToBench -Value 14_CopyBinariesToBench
# ================ End 14_CopyBinariesToBench ================== #

# ================ Start 15_CopyCodeToBench ================ #
  function 15_CopyCodeToBench {
    # Get the user folder and store it in a variable
    $userFolder = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell')
    # Print the user folder
    # Write-Host "User Folder: $userFolder"
    & "$userFolder\Scripts\15_CopyCodeToBench.cmd"
    }
    Set-Alias -Name CopyCodeToBench -Value 15_CopyCodeToBench
# ================ End 15_CopyCodeToBench ================== #

