cls
# Source path to search for ".c" and ".h" generated files
$originDirectory = ".\BL\Projects\Tresos\workspace\Bootloader_Eth\output\generated"

# Destination path where ".h" files will be copied
$includeDirectory = ".\BL\generated\includeTemp"

# Destination path where ".c" files will be copied
$srcDirectory = ".\BL\generated\srcTemp"

# ---------------------------------------------------------------------------------------------------- #
#                                   Process for C files                                                #
# ---------------------------------------------------------------------------------------------------- #

# Verify if "$originDirectory" exists
if (Test-Path -Path $originDirectory) {
    # Verify if "$includeDirectory" exists
    if (-not (Test-Path -Path $includeDirectory)) {
        # If not, create it
        New-Item -ItemType Directory -Path $includeDirectory | Out-Null
        Write-Host "Path Created: $includeDirectory"  -ForegroundColor Yellow
    }

    # Recursive search for ".h" files, in "$originDirectory" and copy them to "$includeDirectory"
    $hFiles = Get-ChildItem -Path $originDirectory -Filter "*.h" -Recurse
    foreach ($file in $hFiles) {
        $includePath = Join-Path -Path $includeDirectory -ChildPath $file.Name
        Copy-Item -Path $file.FullName -Destination $includePath
        Write-Host "Copied: $($file) --> $($includePath)"
    }
} else {
    Write-Host "Source directory doesn't exist: $originDirectory" -ForegroundColor Red
}

# ---------------------------------------------------------------------------------------------------- #
#                                   Process for H files                                                #
# ---------------------------------------------------------------------------------------------------- #

# Verify if "$originDirectory" exists
if (Test-Path -Path $originDirectory) {
    # Verify if "$srcDirectory" exists
    if (-not (Test-Path -Path $srcDirectory)) {
        # If not, create it
        New-Item -ItemType Directory -Path $srcDirectory | Out-Null
        Write-Host "Path Created: $srcDirectory"  -ForegroundColor Yellow
    }

    # Recursive search for ".c" files, in "$originDirectory" and copy them to "$srcDirectory"
    $hFiles = Get-ChildItem -Path $originDirectory -Filter "*.c" -Recurse
    foreach ($file in $hFiles) {
        $destinationPath = Join-Path -Path $srcDirectory -ChildPath $file.Name
        Copy-Item -Path $file.FullName -Destination $destinationPath
        Write-Host "Copied: $($file) --> $($destinationPath)"
    }
} else {
    Write-Host "Source directory doesn't exist: $originDirectory" -ForegroundColor Red
}

# Wait
#Write-Host "Press a key to exit..."
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
