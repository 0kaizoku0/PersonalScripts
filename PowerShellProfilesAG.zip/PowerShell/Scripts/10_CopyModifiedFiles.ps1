
# \\%Bench_seleccionado%\

# Set the paths and Git repository location
$repoPath = "D:\Git\Tem\Master\ars540rn14_fbl"
$destinationPath = "\\Z1D4619W\JoseArmando\ars540rn14_fbl"

# Navigate to the Git repository directory
Set-Location -Path $repoPath

# Get the list of modified files using Git
$modifiedFiles = git diff --name-only

# Filter only the files with .c and .h extensions
$filteredFiles = $modifiedFiles -match "\.(c|h)$"#c|h

# Copy the filtered files to the destination directory
foreach ($file in $filteredFiles) {
    $sourceFile = Join-Path -Path $repoPath -ChildPath $file
    # Write-Output "Source File = $sourceFile"
    $destinationFile = Join-Path -Path $destinationPath -ChildPath $file
    $destinationFolder = Split-Path $destinationFile
    # Write-Output "Destiny = $destinationFolder"
    # Check if the destinationFolder exists
    if (-not (Test-Path $destinationFolder)) {
        # If the path doesn't exist, create it
        New-Item -Path $destinationFolder -ItemType Directory -Force
    }
    Copy-Item -Path $sourceFile -Destination $destinationFolder -Force
    #Start-Process -FilePath "robocopy.exe" -ArgumentList "$sourceFile $destinationPath" -Wait -NoNewWindow
}

Write-Host "Modified .c and .h files copied successfully to the destination directory."