# Define el nombre del archivo que deseas copiar y la ubicaci�n de destino
$prefsDest = "BL\Projects\Tresos\workspace\Bootloader_Eth\"
$prefsOrig = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('MyDocuments'), 'WindowsPowerShell\Scripts\Tresos\.prefs')

# Verifica si la carpeta de destino existe, y si no, cr�ala
if (-not (Test-Path -Path $prefsDest -PathType Container)) {
    New-Item -Path $prefsDest -ItemType Directory
}

# Copia carpeta al destino
Copy-Item -Path $prefsOrig -Destination $prefsDest -Force -Recurse

# Verifica si la copia fue exitosa
if (Test-Path (Join-Path $prefsDest (Split-Path $prefsOrig -Leaf))) {
    Write-Host "La carpeta se copi� exitosamente a la carpeta de documentos del usuario."
} else {
    Write-Host "No se pudo copiar la carpeta."
}

Write-Host "Copia finalizada"